# WhatsApp Primo — Lovable Deployment

## محتويات الحزمة
- backend (Node.js + Baileys)
- src/ (كود البريمو)
- package.json
- .env.example
- README.md

## كيفية النشر على Lovable
1. ارفع كامل المجلد على Lovable.
2. عدّل ملف `.env` بالقيم الخاصة بك (PORT, WEBHOOK_URL, BASE_URL, STORAGE_PATH).
3. شغّل الأمر التالي لتثبيت الحزم:
   ```bash
   npm install
   ```
4. شغّل السيرفر:
   ```bash
   node src/server.js
   ```
5. استخدم API endpoints:
   - POST /sessions { "id":"default" } لإنشاء جلسة
   - GET /qr/default للحصول على QR
   - POST /send/text { "to":"9665...", "message":"Hi", "sessionId":"default" } لإرسال رسالة
6. يمكنك الآن ربط تطبيقك الويب مباشرة مع هذا السيرفر.
