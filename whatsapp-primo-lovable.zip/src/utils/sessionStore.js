const fs = require('fs');
const path = require('path');
function ensureDir(dir){ if(!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true }); }
module.exports = {
  ensureDir,
  sessionPath: (id, cfg) => path.join(cfg.storagePath, id)
}
