const express = require('express');
const router = express.Router();

// GET /qr/:sessionId
router.get('/:sessionId', (req, res) => {
  const id = req.params.sessionId || 'default';
  const s = global.sessions && global.sessions[id];
  if (!s) return res.status(404).json({ ok:false, message:'Session not found' });
  return res.json({ ok:true, qr: s.qr || null, connected: !!s.connected });
});

module.exports = router;
