const express = require('express');
const router = express.Router();
const { createSession } = require('../baileys');

// list sessions
router.get('/', (req, res) => {
  return res.json({ ok:true, sessions: Object.keys(global.sessions||{}) });
});

// create session
router.post('/', async (req, res) => {
  const { id } = req.body;
  if (!id) return res.status(400).json({ ok:false, message:'id required' });
  global.sessions = global.sessions || {};
  if (global.sessions[id]) return res.json({ ok:true, message:'session exists' });
  global.sessions[id] = { connected:false };
  try {
    const sock = await createSession(id);
    global.sessions[id].sock = sock;
    return res.json({ ok:true, message:'session created' });
  } catch (e) {
    console.error(e);
    return res.status(500).json({ ok:false, error: e.message });
  }
});

module.exports = router;
