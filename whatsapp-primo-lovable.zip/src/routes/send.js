const express = require('express');
const router = express.Router();

// POST /send/text
router.post('/text', async (req, res) => {
  const { to, message, sessionId } = req.body;
  if (!to || !message) return res.status(400).json({ ok:false, message:'to & message required' });
  const sid = sessionId || 'default';
  const s = global.sessions && global.sessions[sid];
  if (!s || !s.sock) return res.status(404).json({ ok:false, message:'session not connected' });
  try {
    await s.sock.sendMessage((to.includes('@')? to : to + '@s.whatsapp.net'), { text: message });
    return res.json({ ok:true });
  } catch (e) {
    return res.status(500).json({ ok:false, error: e.message });
  }
});

module.exports = router;
