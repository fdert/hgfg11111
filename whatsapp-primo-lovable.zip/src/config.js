require('dotenv').config();
module.exports = {
  port: process.env.PORT || 3000,
  webhook: process.env.WEBHOOK_URL || '',
  baseUrl: process.env.BASE_URL || 'http://localhost:3000',
  storagePath: process.env.STORAGE_PATH || './sessions'
};
