const { default: makeWASocket, useMultiFileAuthState } = require('@whiskeysockets/baileys');
const qrcode = require('qrcode');
const axios = require('axios');
const config = require('./config');
const { ensureDir, sessionPath } = require('./utils/sessionStore');

ensureDir(config.storagePath);

async function createSession(sessionId='default'){
  const sessionDir = sessionPath(sessionId, config);
  ensureDir(sessionDir);

  const { state, saveCreds } = await useMultiFileAuthState(sessionDir);
  const sock = makeWASocket({ auth: state, printQRInTerminal: true });

  sock.ev.on('creds.update', saveCreds);

  sock.ev.on('connection.update', async (update) => {
    const { qr, connection } = update;
    global.sessions = global.sessions || {};
    global.sessions[sessionId] = global.sessions[sessionId] || {};

    if (qr) {
      try {
        global.sessions[sessionId].qr = await qrcode.toDataURL(qr);
      } catch (e) { console.error('QR gen err', e); }
    }

    if (connection === 'open') {
      global.sessions[sessionId].connected = true;
      global.sessions[sessionId].qr = null;
      console.log(`Session ${sessionId} connected`);
    }
  });

  sock.ev.on('messages.upsert', async ({ messages, type }) => {
    try {
      const m = messages[0];
      if (!m || !m.message) return;
      const payload = {
        session: sessionId,
        from: m.key.remoteJid,
        id: m.key.id,
        message: m.message,
        type
      };
      global.sessions[sessionId].inbox = global.sessions[sessionId].inbox || [];
      global.sessions[sessionId].inbox.unshift(payload);
      if (global.sessions[sessionId].inbox.length > 200) global.sessions[sessionId].inbox.pop();

      if (config.webhook) {
        axios.post(config.webhook, payload).catch(err => console.warn('Webhook err', err.message));
      }
    } catch (e) { console.error(e); }
  });

  return sock;
}

module.exports = { createSession };
