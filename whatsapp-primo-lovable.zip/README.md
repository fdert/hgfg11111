WhatsApp Primo - Backend (Baileys + Node.js)

This is a lightweight 'Primo' package containing the backend server only.
Structure:
- .env.example
- package.json
- src/
    - config.js
    - utils/sessionStore.js
    - baileys.js
    - routes/qr.js
    - routes/send.js
    - routes/sessions.js
    - server.js

Instructions:
1. Copy .env.example to .env and edit values.
2. npm install
3. node src/server.js
4. Create a session: POST /sessions { "id":"default" }
5. Get QR: GET /qr/default
6. Send message: POST /send/text { "to":"9665...", "message":"hi", "sessionId":"default" }
